/**
 * Core IMAP scan logic, decoupled from the HTTP request/response cycle.
 * Mirrors gmailScanService.js pattern — can be called from routes or a BullMQ worker.
 */

import { scanImapInbox } from "./imapClient.js";
import { detectRecurringSubscriptions } from "./subscriptionEngine.js";
import { CONFIDENCE_THRESHOLD } from "../config.js";
import { getFeedbackMerchantMap } from "../db/index.js";
import { getActiveSubscriptionConfidences, batchUpsertSubscriptions } from "../db/index.js";
import {
  buildChargeDataMap,
  enrichSubscriptions,
  buildBypassEntries,
  processCancellations,
  applyLifecycleCancellations,
  applyExpiryRenewalUpdates,
  finalizeScan,
} from "./postDetection.js";
import logger from "../lib/logger.js";

const APPLE_IAP_THRESHOLD = 0.35;

function getThresholdForProvider(provider) {
  return provider === "icloud" ? 0.55 : CONFIDENCE_THRESHOLD;
}

/**
 * @param {{
 *   userId: string,
 *   provider: string,
 *   user: string,
 *   pass: string,
 *   daysBack?: number,
 *   sinceDate?: Date,
 *   force?: boolean,
 * }} opts
 */
export async function runImapScan({ userId, provider, user, pass, daysBack = 730, sinceDate, force = false }) {
  const started = Date.now();

  // ── Step 1: Scan inbox ──────────────────────────────────────────────────────
  const { charges, cancellations, cancelledCharges, scannedCount, checkpoint } = await scanImapInbox({
    provider, user, pass, daysBack, sinceDate: force ? undefined : sinceDate,
  });

  // ── Step 2: Detect subscriptions ────────────────────────────────────────────
  const feedbackMap = await getFeedbackMerchantMap(userId);
  const chargeDataMap = buildChargeDataMap(charges);

  const allSubscriptions = enrichSubscriptions(
    detectRecurringSubscriptions(charges, { feedbackMap }),
    chargeDataMap,
    { source: provider, boostAppleIAP: true }
  );

  // ── Step 3: Threshold filtering ─────────────────────────────────────────────
  const nonAppleThreshold = getThresholdForProvider(provider);
  const confident = allSubscriptions.filter((s) => {
    const raw = chargeDataMap[s.merchant.toLowerCase()];
    const thr = raw?.isAppleIAP ? APPLE_IAP_THRESHOLD : nonAppleThreshold;
    if (s.confidence < thr) {
      logger.info({ merchant: s.merchant, confidence: s.confidence, threshold: thr }, "imap_below_threshold");
      return false;
    }
    return true;
  });

  await batchUpsertSubscriptions(userId, confident);

  // ── Step 4: Bypass loop ─────────────────────────────────────────────────────
  const existingConfidences = await getActiveSubscriptionConfidences(userId);
  const detectedMerchants = new Set(allSubscriptions.map((s) => s.merchant.toLowerCase()));

  const { bypass: appleBypass, expiryUpdates } = await buildBypassEntries({
    charges,
    detectedMerchants,
    existingConfidences,
    source: provider,
    shouldBypass: () => true, // open to all charges
    logger,
  });

  if (appleBypass.length) await batchUpsertSubscriptions(userId, appleBypass);

  // Patch renewal_date for expiry notices where merchant="Apple"
  await applyExpiryRenewalUpdates(userId, expiryUpdates, logger);

  // ── Step 5: Cancellations ───────────────────────────────────────────────────
  const activeMerchants = new Set([
    ...confident.map((s) => s.merchant.toLowerCase()),
    ...appleBypass.map((s) => s.merchant.toLowerCase()),
  ]);

  const cancelledForReview = await processCancellations(userId, {
    cancelledCharges,
    activeMerchants,
    source: provider,
  });

  await applyLifecycleCancellations(userId, cancellations, activeMerchants);

  // ── Step 6: Finalize ────────────────────────────────────────────────────────
  const executionTimeMs = Date.now() - started;
  await finalizeScan(userId, {
    provider,
    scannedMessages: scannedCount,
    detectedCharges: charges.length,
    executionTimeMs,
    checkpoint,
  });

  return {
    subscriptions: [...confident, ...cancelledForReview, ...appleBypass],
    detectedSubscriptions: confident.length + appleBypass.length,
    meta: {
      scannedMessages: scannedCount,
      parsedCharges: charges.length,
      passedConfidenceThreshold: confident.length,
      appleBypassCount: appleBypass.length,
      executionTimeMs,
    },
  };
}
